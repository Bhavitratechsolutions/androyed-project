package com.example.myapplication

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle

class Doctoe_profile_Activity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_doctor_profile)
    }
}