package com.example.myapplication

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle

class doctor_call_Activity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_doctor_call)
    }
}